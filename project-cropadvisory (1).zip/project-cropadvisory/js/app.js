// Advisory data stored in JavaScript objects
const advisories = {
    soil_pH: {
        Acidic: [
            "Apply lime (2-3 tons/ha) to raise pH and improve nutrient availability.",
            "Use ammonium-based nitrogen fertilizers like ammonium sulfate at 40 kg/ha."
        ],
        Neutral: [
            "Maintain pH with balanced fertilizers.",
            "Optimal pH is between 6.0-7.0 for most crops."
        ],
        Alkaline: [
            "Apply sulfur or gypsum to lower pH in alkaline soils.",
            "Ensure balanced micronutrient levels."
        ]
    },
    soil_texture: {
        Loamy: [
            "Loamy soil is ideal for agriculture due to balanced drainage and fertility."
        ],
        Clay: [
            "Clay soils retain moisture well but may require drainage improvements to prevent waterlogging."
        ],
        Sandy: [
            "Sandy soils may require organic matter addition to improve water retention and fertility."
        ]
    },
    observed_problems: {
        "Yellowing Leaves": [
            "Apply nitrogen fertilizers like urea to address nitrogen deficiency.",
            "Check for signs of sulfur deficiency, and apply gypsum if necessary."
        ],
        Wilting: [
            "Ensure adequate irrigation and check for root rot caused by over-watering."
        ],
        "Leaf Spots": [
            "Use fungicides to prevent fungal infections, and remove affected leaves."
        ]
    },
    weather_condition: {
        Rainy: [
            "Monitor crops for fungal diseases due to high humidity.",
            "Ensure proper drainage to prevent waterlogging."
        ],
        Dry: [
            "Ensure consistent irrigation, and consider mulching to conserve moisture."
        ]
    }
};

// Function to generate and display the advisory based on selected conditions
function generateAdvisory() {

    // Get the selected values from dropdowns
    const soil_pH = document.getElementById("soil_pH").value;
    const soil_texture = document.getElementById("soil_texture").value;
    const observed_problems = document.getElementById("observed_problems").value;
    const weather_condition = document.getElementById("weather_condition").value;

    // Collect all relevant advisories
    const advisoryData = [
        ...advisories.soil_pH[soil_pH],
        ...advisories.soil_texture[soil_texture],
        ...advisories.observed_problems[observed_problems],
        ...advisories.weather_condition[weather_condition]
    ];

    // Get the table body element
    const tableBody = document.getElementById("advisory_table").getElementsByTagName("tbody")[0];
    tableBody.innerHTML = ""; // Clear existing rows

    // Insert new rows into the table
    advisoryData.forEach(advisory => {
        const row = tableBody.insertRow();
        const conditionCell = row.insertCell(0);
        const advisoryCell = row.insertCell(1);
        conditionCell.textContent = "Condition";
        advisoryCell.textContent = advisory;
    });
}
